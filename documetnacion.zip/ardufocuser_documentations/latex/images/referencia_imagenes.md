observatorio_amateur.jpg  ---> http://astrocienciasecu.blogspot.com.es/

http://www.compartetusrecuerdos.com/general/camaras/historia-del-enfoque-automatico/
http://fotografiaparaprincipianntes.blogspot.com.es/2014/07/sistema-de-enfoque.html




