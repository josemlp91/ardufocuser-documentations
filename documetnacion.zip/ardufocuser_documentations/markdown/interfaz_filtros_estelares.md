# Interfaz de filtrado de Estrellas


Para visualizar los resultados de los Algoritmos que aplicamos sobre las imágenes,
nos servimos de una pequeña interfaz implementada en Swing Java.

Nos centramos en representar los objetos estelares, marcando en distintos colores.



