## Enlaces:


###Calculo de parametros gausianos con python:
[http://www.mantidproject.org/Python_Peak_Methods](http://www.mantidproject.org/Python_Peak_Methods)

Dato interesante:  fwhm=2.0*math.sqrt(2.0*math.log(2.0))*self.getParameterValue("Sigma")
                    
