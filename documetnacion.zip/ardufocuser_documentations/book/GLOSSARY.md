## FITS

FITS o Flexible Image Transport System es el formato de archivo más utilizado comúnmente en el mundo de la astronomía.

## Fecha Juliana

La fecha juliana, día juliano o DJ (JD, por sus siglas en inglés) es el número de días y fracción transcurridos desde el mediodía del 1º de enero del año 4713 a. C.