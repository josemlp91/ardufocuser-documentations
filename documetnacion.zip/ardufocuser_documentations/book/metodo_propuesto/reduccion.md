# Reduccion

Consiste en seleccionar las partes interesantes para solucionar el problema.
