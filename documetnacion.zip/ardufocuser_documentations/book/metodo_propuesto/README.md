# Metodo propuesto
