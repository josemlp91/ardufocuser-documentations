# Framework

Material utilizado, librerías auxiliares.
