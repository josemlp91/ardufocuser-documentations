# Parte Hardware y electrónica
