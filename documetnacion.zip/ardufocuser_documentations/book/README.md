# Ardufocuser INDI

## RESUMEN

El presente trabajo propone un completo sistema de enfoque diseñado especialmente para aparatos de observación
astronómica.

El reto al que nos enfrentamos en este proyecto es acercar el hardware y el software libre a la
astronomía para crear herramientas avanzadas con un bajo presupuesto.


## ABSTRACT



http://www.astromatic.net/software
